from . import branch
from . import customer
from . import employee
from . import kanbana
from . import loan
from . import newbankaccount
from . import recycle
from . import trasaction



